"""Data layer.

Canonical format everywhere in this engine is a LONG panel:
    date (datetime64), symbol (str), open, high, low, close, volume, sector (str)

Sorted by (symbol, date). One row = one symbol-day = one observation.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

REQUIRED = ["date", "symbol", "open", "high", "low", "close", "volume"]

# strength of the conditional edge planted into the synthetic market (see below)
BOOST = 0.008


def _validate(df: pd.DataFrame) -> pd.DataFrame:
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"panel is missing columns: {missing}")
    df = df.copy()
    df["date"] = pd.to_datetime(df["date"])
    if "sector" not in df.columns:
        df["sector"] = "UNKNOWN"
    df = df.sort_values(["symbol", "date"]).reset_index(drop=True)
    bad = (df["high"] < df["low"]) | (df["close"] <= 0) | (df["open"] <= 0)
    if bad.any():
        raise ValueError(f"{int(bad.sum())} malformed bars (high<low or non-positive price)")
    return df


def load_csv(path: str) -> pd.DataFrame:
    """Load a long panel CSV. Columns: date,symbol,open,high,low,close,volume[,sector]"""
    return _validate(pd.read_csv(path))


def load_yfinance(symbols, start: str, end: str, sectors: dict | None = None) -> pd.DataFrame:
    """Optional convenience loader. Requires `pip install yfinance`.

    For NSE symbols use the .NS suffix, e.g. ['RELIANCE.NS','ONGC.NS','^NSEI'].
    """
    import yfinance as yf

    frames = []
    raw = yf.download(list(symbols), start=start, end=end, auto_adjust=False,
                      group_by="ticker", progress=False)
    for sym in symbols:
        try:
            sub = raw[sym].dropna().reset_index()
        except KeyError:
            continue
        sub.columns = [str(c).lower() for c in sub.columns]
        sub = sub.rename(columns={"adj close": "adj_close"})
        sub["symbol"] = sym
        sub["sector"] = (sectors or {}).get(sym, "UNKNOWN")
        frames.append(sub[["date", "symbol", "open", "high", "low", "close", "volume", "sector"]])
    if not frames:
        raise RuntimeError("yfinance returned nothing usable")
    return _validate(pd.concat(frames, ignore_index=True))


def make_synthetic_panel(n_symbols: int = 40, n_days: int = 1400, seed: int = 7,
                         n_sectors: int = 5) -> pd.DataFrame:
    """Generate a synthetic but *structured* market so the engine has something to find.

    Deliberately embeds three effects the engine should be able to rediscover:
      1. a market factor and sector factors (creates a real correlation graph)
      2. a lead-lag: within each sector, symbol #0 leads the others by one day
      3. a conditional edge: high relative volume + strong close location -> mild
         next-day drift. This is the "state" the miner ought to surface.

    If the engine cannot find (3) on synthetic data, it is broken. If it finds
    lots of "edges" on shuffled data, it is overfitting. Both are testable.
    """
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2020-01-01", periods=n_days)
    sectors = [f"SEC{i}" for i in range(n_sectors)]
    syms = [f"SYM{i:03d}" for i in range(n_symbols)]
    sym_sector = {s: sectors[i % n_sectors] for i, s in enumerate(syms)}
    leaders = {sec: [s for s in syms if sym_sector[s] == sec][0] for sec in sectors}

    market = rng.normal(0, 0.011, n_days)
    sector_f = {sec: rng.normal(0, 0.010, n_days) for sec in sectors}

    rows = []
    for i, sym in enumerate(syms):
        sec = sym_sector[sym]
        beta_m = rng.uniform(0.6, 1.4)
        beta_s = rng.uniform(0.4, 1.2)
        idio = rng.normal(0, 0.016, n_days)
        ret = beta_m * market + beta_s * sector_f[sec] + idio

        # lead-lag: followers inherit part of the leader's previous-day move
        if sym != leaders[sec]:
            lead_ret = beta_s * sector_f[sec]
            ret[1:] += 0.25 * lead_ret[:-1]

        close = 100.0 * np.exp(np.cumsum(ret))
        base_vol = rng.uniform(4e5, 4e6)
        volume = base_vol * np.exp(rng.normal(0, 0.45, n_days) + 3.0 * np.abs(ret))

        # open follows the PREVIOUS close plus a gap; the day's move happens
        # open -> close, which is what the engine actually trades
        prev_close = np.concatenate([[100.0], close[:-1]])
        gap = 0.35 * ret + rng.normal(0, 0.004, n_days)
        op = prev_close * np.exp(gap)
        # intraday excursion beyond the open/close body
        wick = np.abs(rng.normal(0, 0.009, n_days)) + 0.002
        wick_up = wick * rng.uniform(0.3, 1.0, n_days)
        wick_dn = wick * rng.uniform(0.3, 1.0, n_days)
        hi = np.maximum(op, close) * (1 + wick_up)
        lo = np.minimum(op, close) * (1 - wick_dn)

        rows.append(pd.DataFrame({
            "date": dates, "symbol": sym, "open": op, "high": hi,
            "low": lo, "close": close, "volume": volume, "sector": sec,
            "_wick_up": wick_up, "_wick_dn": wick_dn,
        }))

    df = pd.concat(rows, ignore_index=True).sort_values(["symbol", "date"]).reset_index(drop=True)

    # ---- inject the conditional edge (effect 3) ----
    #
    # The trigger is scale-invariant (a volume RATIO and a within-bar location),
    # so it survives the price rescaling applied below.
    #
    # The boost must land on the OPEN -> CLOSE move of day t+1, not on the whole
    # bar. If you scale the open and the high by the same factor, an entry taken
    # at the open sees nothing: the edge cancels out of the label. That is the
    # difference between a tradable drift and an untradable overnight gap.
    g = df.groupby("symbol", sort=False)
    relvol = df["volume"] / g["volume"].transform(lambda s: s.rolling(20, min_periods=20).mean())
    clv = (df["close"] - df["low"]) / (df["high"] - df["low"]).replace(0, np.nan)
    trigger = ((relvol > 1.4) & (clv > 0.75)).fillna(False)

    # b[t] = drift added to day t's open->close move, fired by a trigger on t-1
    b = trigger.groupby(df["symbol"], sort=False).shift(1).fillna(False).astype(float) * BOOST

    # cumulative level multiplier, so the boost persists instead of reversing
    # the following day (a reversal would be a synthetic artefact, not an edge)
    cum = (1.0 + b).groupby(df["symbol"], sort=False).cumprod()
    cum_prev = cum.groupby(df["symbol"], sort=False).shift(1).fillna(1.0)

    df["open"] = df["open"] * cum_prev      # open carries yesterday's level only
    df["close"] = df["close"] * cum         # close carries today's boost
    body_hi = df[["open", "close"]].max(axis=1)
    body_lo = df[["open", "close"]].min(axis=1)
    df["high"] = body_hi * (1.0 + df["_wick_up"])
    df["low"] = body_lo * (1.0 - df["_wick_dn"])
    df = df.drop(columns=["_wick_up", "_wick_dn"])

    return _validate(df)


def build_index(df: pd.DataFrame) -> pd.DataFrame:
    """Equal-weight synthetic index + sector indices, computed cross-sectionally per date.

    Uses only same-day data, so it is causal at day T close.
    """
    d = df.copy()
    d["ret1"] = d.groupby("symbol", sort=False)["close"].pct_change(fill_method=None)
    mkt = d.groupby("date", observed=True)["ret1"].mean().rename("mkt_ret")
    sec = d.groupby(["date", "sector"], observed=True)["ret1"].mean().rename("sec_ret")
    d = d.merge(mkt, on="date", how="left").merge(sec, on=["date", "sector"], how="left")
    return d
